﻿using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.HttpsPolicy;
using ST_KafkaConsumer.Helpers;

namespace ST_KafkaConsumer
{
    public class Startup
    {
       
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        public void ConfigureServices(IServiceCollection services)
        {

            services.AddMvc();
            services.AddControllers();

            // Add application services.
            services.AddSingleton<IHostedService, KafkaConsumerHandler>();

            services.Configure<HstsOptions>(options =>
            {
                options.IncludeSubDomains = true;
                options.MaxAge = TimeSpan.FromDays(365);
            });

            services.AddHealthChecks();

            services.AddDistributedMemoryCache();

            services.AddSession(options =>
            {
                options.Cookie.Name = ".Velocity.Session";
                options.IdleTimeout = TimeSpan.FromMinutes(30);
                options.Cookie.HttpOnly = true;
                options.Cookie.IsEssential = true;
            });
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env, ILoggerFactory loggerFactory)
        {


            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            else
            {
                app.UseExceptionHandler("/Home/Error");
            }

            app.UseHttpsRedirection();
            app.UseStaticFiles();
            app.UseCookiePolicy();
            app.UseRouting();
            app.UseAuthentication();
            app.UseAuthorization();
            app.UseSession();
            app.UseEndpoints(endpoints =>
            {
                endpoints.MapHealthChecks("/healthcheck");
                endpoints.MapControllerRoute("FetchTileDetails", "98bfece9b563860021535c961ee6e6ec53237adf16b2439ae1efbc451ca989e6", new { controller = "DataOperations", action = "FetchTileDetails" });
                endpoints.MapControllerRoute("IdleTimeOut", "6b28df3922fe950e10e640dd0e46e51e38450cbc66b8fce79cd5f31259ee4f29", new { controller = "DataOperations", action = "IdleTimeOut" });
                endpoints.MapControllerRoute("FetchTileData", "98bfece9b563860021535c961ee6e6ec53237adf16b2439ae1efbc451ca989e6", new { controller = "DataOperations", action = "FetchTileData" });
                endpoints.MapControllerRoute("Download", "9fabda69d20222317a26ba1470bbfbbce47ef66bae2f88ba758bab994c72c6d9", new { controller = "DataOperations", action = "Download" });
                endpoints.MapControllerRoute("ManageCRUD", "95c267f146e0d5338a02c7989cca8ede5a3e734a367ccf7c4860795492fc70fc", new { controller = "DataOperations", action = "ManageCRUD" });
                endpoints.MapControllerRoute("FetchLovDetails", "74f6e349496c18387ca1b0537b8d03bde6816f2438d8ff85835cd82e4ff24756", new { controller = "Lov", action = "Index" });
                endpoints.MapControllerRoute("FetchLovCascadedDetails", "bb58d5ab55625afdfc061e7f00ab8440df29bc40c7a057b1832e9bc281b47b66", new { controller = "Lov", action = "Cascaded" });
                endpoints.MapControllerRoute("FetchColumns", "ca221eb806372d319137edff7708f11e8f00bb5b87e1445bb37029d98845c171", new { controller = "DataOperations", action = "FetchColumns" });
                endpoints.MapControllerRoute("LoadGrid", "d7ca8e7c8cc2379e85c327bd8b22283e2d04e931a7e66595247628f461161f15", new { controller = "DataOperations", action = "LoadGrid" });
                endpoints.MapControllerRoute("default", "{controller=Home}/{action=Index}/{id?}");
            });
        }
    }
}
